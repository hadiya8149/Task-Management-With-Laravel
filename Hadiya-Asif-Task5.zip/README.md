Task Management backend with laravel 
implement roles and permissions
request validation with request class
jwt middleware
api request resource table
error logs
sequence of completing tasks
make migrations
make models 
add middleware
